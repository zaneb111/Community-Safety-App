/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package safezone;
import java.io.Serializable;
/**
 *
 * @author zaneb
 */
public class UserCredentials implements Serializable{
    private static String username;
    private static String password;
    private static int age;
    private static String contactNumber;
    private static String name;
    

    // Constructors
    
    public UserCredentials(){}
    public UserCredentials(String username, String password, String name , int age, String contactNumber) {
        UserCredentials.username = username;
        UserCredentials.password = password;
        UserCredentials.age = age;
        UserCredentials.contactNumber = contactNumber;
         UserCredentials.name = name;
        
    }

    // Getters and Setters
    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        UserCredentials.name = name;
    }

    // Getter and Setter for 'address'
    
    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        UserCredentials.username = username;
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        UserCredentials.password = password;
    }

    public static int getAge() {
        return age;
    }

    public static void setAge(int age) {
        UserCredentials.age = age;
    }

    public static String getContactNumber() {
        return contactNumber;
    }

    public static void setContactNumber(String contactNumber) {
        UserCredentials.contactNumber = contactNumber;
    }

    // Other methods as needed
}
