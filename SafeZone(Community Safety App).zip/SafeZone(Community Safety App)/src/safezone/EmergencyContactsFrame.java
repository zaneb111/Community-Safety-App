
package safezone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmergencyContactsFrame extends javax.swing.JFrame  {
    private EmergencyContacts emergencyContacts;

    private JTextField nameField;
    private JTextField relationshipField;
    private JTextField phoneNumberField;
    private JTextField emailAddressField;
    private JTextField addressField;
    private JList<Contact> contactList;

    public EmergencyContactsFrame() throws FileNotFoundException, ClassNotFoundException {
        this.emergencyContacts = new EmergencyContacts();

        setTitle("Emergency Contacts");
        setSize(1366, 781);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initComponent();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1366, 768));
        setPreferredSize(new java.awt.Dimension(1366, 789));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void initComponent() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(0, 102, 102));
        mainPanel.setBorder(BorderFactory.createLineBorder(new Color(0,51,51), 5)); // Dark Blue Border

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(5, 2));
        formPanel.setBackground(new Color(0, 102, 102));
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(0,51,51), 5)); // Dark Blue Border

        nameField = createStyledTextField();
        relationshipField = createStyledTextField();
        phoneNumberField = createStyledTextField();
        emailAddressField = createStyledTextField();
        addressField = createStyledTextField();

        formPanel.add(createLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(createLabel("Relationship:"));
        formPanel.add(relationshipField);
        formPanel.add(createLabel("Phone Number:"));
        formPanel.add(phoneNumberField);
        formPanel.add(createLabel("Email Address:"));
        formPanel.add(emailAddressField);
        formPanel.add(createLabel("Address:"));
        formPanel.add(addressField);

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setBackground(new Color(0, 102, 102));
        buttonsPanel.setBorder(BorderFactory.createLineBorder(new Color(0,51,51), 5)); // Dark Blue Border
        JButton addContactButton = createStyledButton("Add Contact");
        JButton removeContactButton = createStyledButton("Remove Contact");
        JButton ekzitbutton = createStyledButton("Exit");


        addContactButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addContact(); 
            }
        });
        ekzitbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Exit();
            }
        });

        removeContactButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeContact();
            }
        });

        buttonsPanel.add(addContactButton);
        buttonsPanel.add(removeContactButton);
        buttonsPanel.add(ekzitbutton);


        // Contact List
         // Contact List
contactList = new JList<>();
contactList.setBackground(new Color(0, 102, 102)); // Turquoise color
JScrollPane listScrollPane = new JScrollPane(contactList);
listScrollPane.setBorder(BorderFactory.createLineBorder(new Color(0, 51, 51), 5)); // Dark Blue Border
// Dark Blue Border

        // Notification Button
        JButton notifyButton = createStyledButton("Notify");
        notifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    notifyContacts();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(EmergencyContactsFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(listScrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);
        mainPanel.add(notifyButton, BorderLayout.EAST);
        


        mainPanel.setPreferredSize(new Dimension(1366, 781));
    add(mainPanel);
    pack();
    }

    private JTextField createStyledTextField() {
        JTextField textField = new JTextField();
        textField.setFont(new Font("Trebuchet MS", Font.PLAIN, 18));
        textField.setBackground(new Color(173, 216, 230)); // Light Blue
        return textField;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Trebuchet MS", Font.PLAIN, 18));
        label.setForeground(Color.WHITE);
        return label;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Trebuchet MS", Font.PLAIN, 16));
        button.setBackground(new Color(46, 139, 87)); // Dark SeaGreen
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createRaisedBevelBorder());
        return button;
    }
    private void addContact() {
        String name = nameField.getText();
        String relationship = relationshipField.getText();
        String phoneNumber = phoneNumberField.getText();
        String emailAddress = emailAddressField.getText();
        String address = addressField.getText();

        Contact contact = new Contact();
        contact.setName(name);
        contact.setRelationship(relationship);
        contact.setPhoneNumber(phoneNumber);
        contact.setEmailAddress(emailAddress);
        contact.setAddress(address);

        emergencyContacts.addContact(contact);
        updateContactList();
        clearFields();
    }
    private void Exit(){
        USER u= new USER();
      u.setVisible(true);
      this.setVisible(false);
    }
    private void removeContact() {
        int selectedIndex = contactList.getSelectedIndex();
        if (selectedIndex != -1) {
            emergencyContacts.getContacts().remove(selectedIndex);
            updateContactList();
        }
    }

    private void notifyContacts() throws FileNotFoundException {
        StringBuilder message = new StringBuilder("Emergency: ");

        for (Contact contact : emergencyContacts.getContacts()) {
            message.append(contact.getName()).append(" - ").append(contact.getPhoneNumber()).append("\n");
        }
        try {
            ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("emergencycontact.txt"));
            for (Contact contact : emergencyContacts.getContacts()) {
                oos.writeObject(contact);
            }
            oos.close();
        } catch (IOException ex) {
           
            System.out.println("File not found");
        }
        

        emergencyContacts.notified(message.toString());
    }

    private void updateContactList() {
        contactList.setListData(emergencyContacts.getContacts().toArray(new Contact[0]));
    }

    private void clearFields() {
        nameField.setText("");
        relationshipField.setText("");
        phoneNumberField.setText("");
        emailAddressField.setText("");
        addressField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    new EmergencyContactsFrame();
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(EmergencyContactsFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(EmergencyContactsFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
