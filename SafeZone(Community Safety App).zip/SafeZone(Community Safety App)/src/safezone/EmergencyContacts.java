/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package safezone;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

class EmergencyContacts implements Notifiable {
    private List<Contact> contacts;
    Contact c=new Contact();
    public EmergencyContacts() throws FileNotFoundException, ClassNotFoundException {
        this.contacts = new ArrayList<>();
        try {
            ObjectInputStream ois=new ObjectInputStream(new FileInputStream("emergencycontact.txt"));
            while(true){
                 c =(Contact)ois.readObject();
            contacts.add(c);
        }
        } catch (IOException ex) {
            System.out.println("File not found");
        }
        
    }

    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    @Override
    public void notified(String message) {
        JOptionPane.showMessageDialog(null, message, "Notification", JOptionPane.INFORMATION_MESSAGE);
    }
}

